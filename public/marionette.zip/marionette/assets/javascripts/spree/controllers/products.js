// Spree.ProductsController = {
// 	var products_view = new Spree.ProductsView()
// 	products_view.on("itemview:product:show", function(childView, model){
// 	  console.log("Received itemview:product:show event on model ", model)
// 	});
// }