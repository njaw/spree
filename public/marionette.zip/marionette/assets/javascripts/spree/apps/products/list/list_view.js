SpreeStore.module('Products.List',function(ProductsList, SpreeStore, Backbone,Marionette,$,_){
  ProductsList.ProductPreview = Backbone.Marionette.ItemView.extend({
    tagName: 'li',
    template: "#product-template",
    className: 'product'
  });

  ProductsList.ProductsView = Backbone.Marionette.CollectionView.extend({
    tagName: "ul",
    template: "#products-template",
    itemView: SpreeStore.ProductPreview
  });
});