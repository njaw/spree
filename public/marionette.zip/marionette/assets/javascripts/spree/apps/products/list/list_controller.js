SpreeStore.module('Products.List',function(ProductsList, SpreeStore, Backbone,Marionette,$,_){
  ProductsList.Controller = {
    listProducts: function() {
      var products = SpreeStore.request("products");
      var products_list_view = new ProductsList.ProductsView({
        collection: products
      });

      SpreeStore.mainRegion.show(products_list_view)
    }
  }
});