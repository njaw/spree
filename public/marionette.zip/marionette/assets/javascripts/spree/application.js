Spree = {}
SpreeStore = new Backbone.Marionette.Application()

SpreeStore.addRegions({
    mainRegion: "#content"
});

SpreeStore.on("initialize:after", function(){
   SpreeStore.Products.List.Controller.listProducts();
});

$(document).ready(function() {
  SpreeStore.start();
})
