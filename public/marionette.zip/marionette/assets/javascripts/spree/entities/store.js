SpreeStore.module('Entities',function(Entities, SpreeStore, Backbone,Marionette,$,_){
  Entities.Product = Backbone.Model.extend({});

  Entities.Products = Backbone.Collection.extend({
    model: Entities.Product
  });

  var products;

  var initializeProducts = function(){ 
    products = new Entities.Products([
      { id: 1, name: 'Tote Bag' },
      { id: 2, name: 'Foobar' }
    ]);
  };

  var API = {
    getProducts: function() {
      if (products === undefined) {
        initializeProducts();
      }
      return products;
    }
  }

  SpreeStore.reqres.setHandler("products", function() {
    return API.getProducts();
  });
})